package com.cg.dao;

import java.util.List;

import com.cg.entities.Query_Master;

public interface QueryRepositry {

	public Query_Master save(Query_Master query_Master);
	public List<Query_Master> showTransactions();
	public Query_Master getTransaction(int query_Master);
	public void update(Query_Master query_Master);
}
