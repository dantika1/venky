package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.QueryRepositry;
import com.cg.entities.Query_Master;

@Service
@Transactional
public class QueryServiceImpl implements QueryService{

	@Autowired
	QueryRepositry queryRepositry;
	
	@Override
	public Query_Master save(Query_Master query_Master) {
		return queryRepositry.save(query_Master);
	}

	@Override
	public List<Query_Master> showTransactions() {
		return queryRepositry.showTransactions();
	}

	@Override
	public Query_Master getTransaction(int query_Master) {
		return queryRepositry.getTransaction(query_Master);
	}

	@Override
	public void update(Query_Master query_Master) {
		queryRepositry.update(query_Master);		
	}

}
