export class Customer {
    custid: number;
    fullname: string;
    password: string;
    email: string;
    zipcode: string
	mobileno: string;
	country: string
	address: string;
    city: string;
    
}