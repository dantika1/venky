import {Injectable} from '@angular/core';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import { Customer } from '../_models';
import {Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';
 
const httpOptions = {
 headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
  
@Injectable()
export class Customerservice {

 
  constructor(private http:HttpClient) {}
 
  private userUrl = 'http://localhost:8060/cust';
  
  // private list= 'http://localhost:8060/cust/details';
 
  public getCustomers(): Observable<Customer> {
    return this.http.get<Customer>(this.userUrl+"/"+"user/6");
  }
 
  // public getCustomers(data1): Observable<Customer> {
  //   return this.http.get<Customer>(this.userUrl+"/"+"user/data1");
  // }
 
  public getlist(): Observable<Customer[]>{
    return this.http.get<Customer[]>(this.userUrl+"/"+"details");
  }
 
}