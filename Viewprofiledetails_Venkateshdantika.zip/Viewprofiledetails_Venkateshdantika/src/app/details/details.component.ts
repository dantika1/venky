﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';
import { User } from '../_models';
import { UserService } from '../_services';
import { Customer } from '../_models/Customer';
import { Customerservice } from '../_services';
import { AlertService, AuthenticationService } from '../_services';

@Component({
	selector : 'details-root',
	templateUrl: 'details.component.html'
})
export class DetailsComponent implements OnInit{
customer : Customer;
currentUser: User;

//public Customer = [];
list : Customer[]=[];
  constructor(private customerService: Customerservice,private userService: UserService) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
	  }

  ngOnInit() {
	  this.customerService.getCustomers()
      .subscribe( data => 
        this.customer= data
    // this.customerService.getCustomers(data)
    // .subscribe( data => 
    //   this.customer= data
      );
      this.customerService.getlist().subscribe(data =>this.list= data);
      console.log(this.customer);
  }
 
  
}
