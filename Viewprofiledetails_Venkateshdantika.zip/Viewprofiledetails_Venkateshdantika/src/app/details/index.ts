﻿export * from './details.component';
// export * from './list.component';
