package com.example.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.CustomerDetails;
import com.example.service.Icustomerservice;

@RestController
//@CrossOrigin(origins = "http://localhost:4200",allowedHeaders = "*")
@CrossOrigin("http://localhost:4200")
@RequestMapping("/cust")
public class Customercontroller {

	@Autowired
	Icustomerservice icustomerservice;

	List<CustomerDetails> customers = new ArrayList<CustomerDetails>();

	@GetMapping(value = "/details"/*headers="Accept=application/json"*/)
	public List<CustomerDetails> customerData() {
		
		/*
		 * 
		 * CustomerDetails customer = new CustomerDetails(9, "Venkatesh",
		 * "venky@gmail.com", "venky123", "7894563210", "choutuppal", "hyderabad",
		 * "15655", "India");
		 * 
		 * CustomerDetails customer1 = new CustomerDetails(10, "Venky",
		 * "venky123@gmail.com", "venkatesh123", "7894563210", "choutuppal",
		 * "hyderabad", "15655", "India");
		 * 
		 * icustomerservice.newCustomer(customer);
		 * icustomerservice.newCustomer(customer1); customers.add(customer);
		 * customers.add(customer1);
		 */		 
		/*
		 * customers=icustomerservice.list(); System.out.println(customers);
		 * 
		 */
		System.out.println(icustomerservice.getting());
		return icustomerservice.getting();
	}

	@GetMapping(value = "/user/{Id}"/* , method = RequestMethod.GET,headers="Accept=application/json" */)
	public Optional<CustomerDetails> getcustbyid(@PathVariable("Id") int id) {
		System.out.println(icustomerservice.getcustbyid(id));
		return icustomerservice.getcustbyid(id);

	}

	
	/*
	 * @RequestMapping(value="/{Id}",method = RequestMethod.PUT) public
	 * CustomerDetails updatecustbyid(@PathVariable("Id")int id,@RequestBody
	 * CustomerDetails cust) { return icustomerservice.updatecustbyid(cust);
	 * 
	 * }
	 */
	 

}
