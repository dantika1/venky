package com.example.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component

//@Table(name="Customer_details")
public class CustomerDetails implements Serializable{
	
	
	
	
	
	
	
	@Override
	public String toString() {
		return "Profile_details [Custid=" + Custid + ", full_name=" + full_name + ", email=" + email + ", password="
				+ password + ", phone_no=" + phone_no + ", address=" + address + ", city=" + city + ", zip_code="
				+ zip_code + ", Country=" + Country + "]";
	}




	@Id
	  private int Custid;
	  private String full_name;
      private String email;
      private String password;
      private String phone_no;
      private String address;
      private String city;
      private String zip_code;
      private String Country;
    

     
	 

	  public CustomerDetails(int custid, String full_name, String email, String password, String phone_no, String address,
			String city, String zip_code, String country) {
		super();
		this.Custid = custid;
		this.full_name = full_name;
		this.email = email;
		this.password = password;
		this.phone_no = phone_no;
		this.address = address;
		this.city = city;
		this.zip_code = zip_code;
		this.Country = country;
	}




	public int getCustid() {
			return this.Custid;
		}




		public void setCustid(int custid) {
			this.Custid = custid;
		}

	public String getFull_name() {
		return full_name;
	}




	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	public String getPhone_no() {
		return phone_no;
	}




	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public String getCity() {
		return city;
	}




	public void setCity(String city) {
		this.city = city;
	}




	public String getZip_code() {
		return zip_code;
	}




	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}




	public String getCountry() {
		return Country;
	}




	public void setCountry(String country) {
		this.Country = country;
	}




	public CustomerDetails() {
		
	}

}
