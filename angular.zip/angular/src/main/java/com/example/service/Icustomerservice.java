package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.model.CustomerDetails;

public interface Icustomerservice {
	public void newCustomer(CustomerDetails customerDetails);
    public Optional<CustomerDetails> getcustbyid(int id);
	//public CustomerDetails updatecustbyid(CustomerDetails cust);
    public List<CustomerDetails> getting();
}
