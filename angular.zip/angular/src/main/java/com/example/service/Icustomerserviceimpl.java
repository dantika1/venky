package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.Icustomerdao;
import com.example.model.CustomerDetails;

@Service
@Transactional
public class Icustomerserviceimpl implements Icustomerservice {

	List<CustomerDetails> customers = new ArrayList<CustomerDetails>();
	@PersistenceContext
	EntityManager entityManager;
	@Autowired
	Icustomerdao icustomerdao;

	public void newCustomer(CustomerDetails customerDetails) {

		icustomerdao.save(customerDetails);

	}

	public Optional<CustomerDetails> getcustbyid(int id) {
		// TODO Auto-generated method stub
		return icustomerdao.findById(id);
	}

	/*
	 * public CustomerDetails updatecustbyid(CustomerDetails cust) { // TODO
	 * Auto-generated method stub return icustomerdao.save(cust); }
	 */
	public List<CustomerDetails> getting() {

		
	

		return icustomerdao.findAll();
	}
}
